costa_rica = {

   "ciudades": ["San José", "Limón", "Cartago", "Puntarenas"],

   "comidas": ["gallo pinto", "casado", "tamales", "chifrijo", "olla de carne"]

}

def iterarDiccionario4(diccionario):
    for clave, valores in diccionario.item():
         print(f"{len(valores)} {clave.upper()}")

print("\n iterar a tráves de un diccionario con valores de la lista")
iterarDiccionario4(costa_rica)