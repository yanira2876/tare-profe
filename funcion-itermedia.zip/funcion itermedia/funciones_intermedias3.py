cantantes = [

   {"nombre": "Ricky Martin", "pais": "Puerto Rico"},

   {"nombre": "Chayanne", "pais": "Puerto Rico"},

   {"nombre": "José José", "pais": "México"},

   {"nombre": "Juan Luis Guerra", "pais": "República Dominicana"}

]


def iterarDiccionario3 (artista, nac):
    for diccionario in nac:
        if artista in diccionario:
         print(diccionario[artista])
#ejemplo de uso
iterarDiccionario3("nombre", cantantes)
iterarDiccionario3("pais", cantantes)